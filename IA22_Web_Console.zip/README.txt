IA22 Web Console
Auteur : Zoubirou Mohammed Ilyes | NetSecurePro IA
ORCID : https://orcid.org/0009-0007-7571-3178
Site : https://milyes.github.io/

Fonction :
- Console Web IA CLI
- Analyse IA hybride Bash, JSON, IA22