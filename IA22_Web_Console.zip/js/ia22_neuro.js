function lancerIA22() {
    const result = "🧠 IA22 : Analyse terminée.\n✔️ Code prêt.";
    document.getElementById("resultat").innerText = result;
}