# IA22 Web Console - NetSecurePro IA
---
## Auteur : Zoubirou Mohammed Ilyes
🔗 ORCID : https://orcid.org/0009-0007-7571-3178  
🏢 Organisation : NetSecurePro IA

## Structure :
- index.html : Console IA
- landing.html : Page d'accueil
- css/style.css : Style général
- js/langue.js + ia22_neuro.js : Scripts IA22
- assets/ : Images et logos

## Fonction : WebView IA CLI / Analyse IA / Offline & Online